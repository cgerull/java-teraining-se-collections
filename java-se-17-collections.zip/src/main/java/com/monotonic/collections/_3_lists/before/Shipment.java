package com.monotonic.collections._3_lists.before;

import com.monotonic.collections.common.Product;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Shipment implements Iterable<Product>
{
    private static final int LIGHT_VAN_MAX_WEIGHT = 20;

    public void add(Product product)
    {
        // TODO
    }

    public boolean replace(Product oldProduct, Product newProduct)
    {
        // TODO

        return true;
    }

    public void prepare()
    {
        // TODO
    }

    public List<Product> getHeavyVanProducts()
    {
        return null;
    }

    public List<Product> getLightVanProducts()
    {
        return null;
    }

    public Iterator<Product> iterator()
    {
        return null;
    }

    public boolean stripHeavyProducts()
    {
        return false;
    }
}
