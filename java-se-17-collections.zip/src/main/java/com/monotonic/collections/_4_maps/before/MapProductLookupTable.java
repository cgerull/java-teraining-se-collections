package com.monotonic.collections._4_maps.before;

import java.util.HashMap;
import java.util.Map;

public class MapProductLookupTable implements ProductLookupTable
{
    @Override
    public void addProduct(final Product productToAdd)
    {
    }

    @Override
    public Product lookupById(final int id)
    {
        return null;
    }

    @Override
    public void clear()
    {
    }
}
