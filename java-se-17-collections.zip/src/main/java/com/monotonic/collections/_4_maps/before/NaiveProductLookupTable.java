package com.monotonic.collections._4_maps.before;

public class NaiveProductLookupTable implements ProductLookupTable
{
    @Override
    public void addProduct(final Product productToAdd)
    {
    }

    @Override
    public Product lookupById(final int id)
    {
        return null;
    }

    @Override
    public void clear()
    {
    }
}
