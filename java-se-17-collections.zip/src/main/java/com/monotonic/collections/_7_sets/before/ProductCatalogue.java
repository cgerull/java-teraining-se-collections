package com.monotonic.collections._7_sets.before;

import com.monotonic.collections.common.Product;
import com.monotonic.collections.common.Supplier;

import java.util.*;

public class ProductCatalogue implements Iterable<Product>
{
    public void addSupplier(final Supplier supplier)
    {
    }

    @Override
    public Iterator<Product> iterator()
    {
        return null;
    }
}
